package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.SinhVien;
import util.ConnectionFactory;

public class SinhVienImplDAO implements DAO{
	
	String driverClassName = "com.mysql.jdbc.Driver";
    String connectionUrl = "jdbc:mysql://localhost:3306/k7g";
    String dbUser = "root";
    String dbPwd = "";
    private String selectall = "select * from sinhvien";
    private String sqlInsert = "Insert into sinhvien (id,name,diachi,tenlop,namsinh) values (?,?,?,?,?)";
    private String sqlUpdate = "update sinhvien set name=?,diachi=?,tenlop=?,namsinh=? where id=?";
    private String sqlDelete = "delete from SINHVIEN where ID=?";
    private String sqlFindByID = "select * from sinhvien  where id=?";
    private String sqlFindByName = "select *from sinhvien where name=?";

    private static void closeConnec(Connection con) {
        try {
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private static void closeStatement(Statement stmt) {
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
                throw new RuntimeException(e);
            }
        }
    }

    private static void closeResultSet(ResultSet resultSet) {
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
                throw new RuntimeException(e);
            }
        }
    }

    private Connection getConnection() throws SQLException {
        Connection conn=null;
        try {
            Class.forName(driverClassName);
            conn = DriverManager.getConnection(connectionUrl, dbUser, dbPwd);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e1){
            e1.printStackTrace();
        }
        return conn;
    }

	@Override
	public ArrayList<SinhVien> getAll() throws SQLException {
		Connection con = getConnection();
        Statement st = null;
        ArrayList<SinhVien> listAll = new ArrayList<SinhVien>();
        ResultSet rs = null;
        if (con != null) {
            st = con.createStatement();
            rs = st.executeQuery(selectall);
            while (rs.next()) {
                SinhVien sv = new SinhVien(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));                
                listAll.add(sv);
            }
        }
        return listAll;
	}

	@Override
	public void insert(SinhVien sv) throws SQLException {
		Connection con = getConnection();
        PreparedStatement pr = null;
        if (con != null) {
            pr = con.prepareStatement(sqlInsert);
            
            pr.setInt(1, sv.getId());
            pr.setString(2, sv.getName());
            pr.setString(3, sv.getDiaChi());
            pr.setString(4, sv.getTenLop());
            pr.setString(5, sv.getNamSinh());
            System.out.println(pr.toString());
            pr.executeUpdate();
            pr.close();

        }
		
	}

	@Override
	public void update(SinhVien sv) throws SQLException {
		Connection con = getConnection();
        PreparedStatement pr = null;

        pr = con.prepareStatement(sqlUpdate);
        pr.setString(1, sv.getName());
        pr.setString(2, sv.getDiaChi());
        pr.setString(3, sv.getTenLop());
        pr.setString(4, sv.getNamSinh());
        pr.setInt(5, sv.getId());
        pr.executeUpdate();
        pr.close();
		
	}

	@Override
	public boolean delete(SinhVien sv) throws SQLException {
		Connection con = getConnection();
        PreparedStatement pr = null;
        int k = 0;
        pr = con.prepareStatement(sqlDelete);
        pr.setInt(1, sv.getId());
        k = pr.executeUpdate();
        pr.close();

        if (k > 0) {
            return true;
        }
        return false;
	}

	@Override
	public SinhVien findByID(int id) throws SQLException {
		Connection con = null;
        PreparedStatement stmt = null;
        con = getConnection();
        stmt = con.prepareStatement(sqlFindByID);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            SinhVien sv = new SinhVien(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
            rs.close();
            return sv;
        } else {
            return null;
        }
	}

	@Override
	public SinhVien findByName(String name) throws SQLException {
		Connection con = null;
        PreparedStatement stmt = null;
        con = getConnection();
        stmt = con.prepareStatement(sqlFindByName);
        stmt.setString(1, name);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            SinhVien sv = new SinhVien(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
            rs.close();
            stmt.close();
            return sv;
        } else {
            return null;
        }
	}

	public void showData() throws SQLException {
        ArrayList<SinhVien> listSinhVien = getAll();
        for (SinhVien sv : listSinhVien) {	
            System.out.println(sv.toString());
        }
    }

    public static void main(String args[]) {
        try {
            SinhVienImplDAO demo = new SinhVienImplDAO();

            SinhVien sv = new SinhVien(3,"Viet Hoang", "Tan Thinh Thai Nguyen", "ktpm21", "2004");
            demo.getAll();
//             demo.insert(sv);
             SinhVien sv1 = demo.findByID(3);


            demo.showData();
            sv1.setNamSinh("204");
            System.out.println("sau update");
            demo.update(sv1);
//            demo.delete(sv1);
//            System.out.println("Sau khi xoa sinh vien thu 2");
            demo.showData();


        }
        catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
