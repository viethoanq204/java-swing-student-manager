package model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class SinhVienTableModel extends AbstractTableModel {
    private ArrayList<SinhVien> dsSinhVien = null;
    private Object[][] data = null;
    private String[] columnNames = {"Mã SV", "Họ tên", "Địa chỉ", "Lớp", "Năm sinh"};

    public SinhVienTableModel(ArrayList<SinhVien> _dsSinhVien) {
        System.out.println("innit sinhvienmodel");
        dsSinhVien = _dsSinhVien;
        data = new Object[dsSinhVien.size()][];

        for (int i = 0; i < dsSinhVien.size(); i++) {
            SinhVien sv = dsSinhVien.get(i);
            Object[] row = {
                sv.getId(),
                sv.getName(),
                sv.getDiaChi(),
                sv.getTenLop(),
                sv.getNamSinh()
            };
            data[i] = row;
        }
    }

    @Override
    public int getRowCount() {
        return data.length;
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data[rowIndex][columnIndex];
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
}
