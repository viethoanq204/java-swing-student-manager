package main;

import java.sql.SQLException;

import controller.SinhVienController;
import dao.SinhVienImplDAO;
import model.SinhVienTableModel;
import view.SinhVienView;

public class Main {
	 public static void main(String[] args) {
	        
	        
	        try {
	            SinhVienImplDAO sinhVienDAO = new SinhVienImplDAO();
	            SinhVienTableModel sinhvienModel = new SinhVienTableModel(sinhVienDAO.getAll());
	            SinhVienView sinhvienView = new SinhVienView();
	            SinhVienController controller = new SinhVienController(sinhvienView, sinhvienModel);
	            controller.showSinhVienView();
	        } catch (SQLException e) {
	            //sinhvienView.showMessage(e.toString());
	        }
	    }
}
