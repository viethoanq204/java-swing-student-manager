/**
 * 
 */
/**
 * 
 */
module SinhVienFrame {
	requires java.sql;
	requires java.desktop;
}